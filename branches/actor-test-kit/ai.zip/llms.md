# zw.fhir.ig.lab#0.1.0: Zimbabwe Laboratory Ordering and Results IG

## Pages

* [Home](index.md)
* [Order Push Requirements](Requirements-zw-lab-order-push.md)
* [Order Push Requirements - Testing](Requirements-zw-lab-order-push-testing.md)
* [Lab Result Repository](ActorDefinition-lab-result-repository.md)
* [Lab Result Consumer - TTL Representation](ActorDefinition-lab-result-consumer.ttl.md)
* [Lab Result Consumer - XML Representation](ActorDefinition-lab-result-consumer.xml.md)
* [Order Pull Requirements - Testing](Requirements-zw-lab-order-pull-testing.md)
* [Downloads](downloads.md)
* [Lab Order Repository](ActorDefinition-lab-order-repository.md)
* [](Requirements-zw-lab-order-pull.change.history.md)
* [Result Push Requirements - JSON Representation](Requirements-zw-lab-result-push.json.md)
* [](ActorDefinition-lab-order-repository.change.history.md)
* [Result Pull Requirements - TTL Representation](Requirements-zw-lab-result-pull.ttl.md)
* [Lab Order Placer - TTL Representation](ActorDefinition-lab-order-placer.ttl.md)
* [Lab Result Provider - Testing](ActorDefinition-lab-result-provider-testing.md)
* [Result Pull Requirements - JSON Representation](Requirements-zw-lab-result-pull.json.md)
* [Lab Order Placer - JSON Representation](ActorDefinition-lab-order-placer.json.md)
* [Actors](actors.md)
* [Testing](testing.md)
* [Result Pull Requirements - XML Representation](Requirements-zw-lab-result-pull.xml.md)
* [](ActorDefinition-lab-result-consumer.change.history.md)
* [Lab Order Placer](ActorDefinition-lab-order-placer.md)
* [Lab Result Repository - JSON Representation](ActorDefinition-lab-result-repository.json.md)
* [Lab Result Provider - TTL Representation](ActorDefinition-lab-result-provider.ttl.md)
* [Artifacts Summary](artifacts.md)
* [Lab Order Repository - TTL Representation](ActorDefinition-lab-order-repository.ttl.md)
* [](Requirements-zw-lab-result-pull.change.history.md)
* [Lab Order Fulfiller - Testing](ActorDefinition-lab-order-fulfiller-testing.md)
* [Result Pull Requirements](Requirements-zw-lab-result-pull.md)
* [Lab Order Repository - JSON Representation](ActorDefinition-lab-order-repository.json.md)
* [Lab Order Placer - Testing](ActorDefinition-lab-order-placer-testing.md)
* [Order Push Requirements - JSON Representation](Requirements-zw-lab-order-push.json.md)
* [Lab Order Fulfiller - TTL Representation](ActorDefinition-lab-order-fulfiller.ttl.md)
* [Order Push Requirements - XML Representation](Requirements-zw-lab-order-push.xml.md)
* [Lab Result Provider - JSON Representation](ActorDefinition-lab-result-provider.json.md)
* [Lab Order Repository - XML Representation](ActorDefinition-lab-order-repository.xml.md)
* [About](about.md)
* [Lab Result Repository - XML Representation](ActorDefinition-lab-result-repository.xml.md)
* [](ActorDefinition-lab-order-placer.change.history.md)
* [Order Push Requirements - TTL Representation](Requirements-zw-lab-order-push.ttl.md)
* [](ActorDefinition-lab-result-repository.change.history.md)
* [Order Pull Requirements](Requirements-zw-lab-order-pull.md)
* [Lab Result Consumer - JSON Representation](ActorDefinition-lab-result-consumer.json.md)
* [Lab Result Repository - Testing](ActorDefinition-lab-result-repository-testing.md)
* [Lab Order Placer - XML Representation](ActorDefinition-lab-order-placer.xml.md)
* [Lab Order Repository - Testing](ActorDefinition-lab-order-repository-testing.md)
* [](ActorDefinition-lab-order-fulfiller.change.history.md)
* [](Requirements-zw-lab-result-push.change.history.md)
* [Result Push Requirements](Requirements-zw-lab-result-push.md)
* [Result Push Requirements - TTL Representation](Requirements-zw-lab-result-push.ttl.md)
* [Lab Result Repository - TTL Representation](ActorDefinition-lab-result-repository.ttl.md)
* [Result Pull Requirements - Testing](Requirements-zw-lab-result-pull-testing.md)
* [Lab Result Provider - XML Representation](ActorDefinition-lab-result-provider.xml.md)
* [Lab Result Provider](ActorDefinition-lab-result-provider.md)
* [](ActorDefinition-lab-result-provider.change.history.md)
* [](Requirements-zw-lab-order-push.change.history.md)
* [Lab Result Consumer - Testing](ActorDefinition-lab-result-consumer-testing.md)
* [Lab Order Fulfiller](ActorDefinition-lab-order-fulfiller.md)
* [Lab Order Fulfiller - XML Representation](ActorDefinition-lab-order-fulfiller.xml.md)
* [Result Push Requirements - Testing](Requirements-zw-lab-result-push-testing.md)
* [Order Pull Requirements - JSON Representation](Requirements-zw-lab-order-pull.json.md)
* [Result Push Requirements - XML Representation](Requirements-zw-lab-result-push.xml.md)
* [Order Pull Requirements - XML Representation](Requirements-zw-lab-order-pull.xml.md)
* [Lab Order Fulfiller - JSON Representation](ActorDefinition-lab-order-fulfiller.json.md)
* [Order Pull Requirements - TTL Representation](Requirements-zw-lab-order-pull.ttl.md)
* [Lab Result Consumer](ActorDefinition-lab-result-consumer.md)

## Resources

### CodeSystems

* [ZW Laboratory Tests](CodeSystem-zw-lab-tests.md)
* [ZW National Laboratory List](CodeSystem-zw-laboratories.md)
* [ZW Reason for Test](CodeSystem-zw-reason-for-test.md)
* [ZW Specimen Rejection Reasons](CodeSystem-zw-rejection-reasons.md)
* [ZW Report Review State](CodeSystem-zw-report-review-state.md)
* [ZW Specimen Types](CodeSystem-zw-sample-types.md)
* [ZW Lab Task Input Type](CodeSystem-zw-task-input-type.md)
* [ZW Lab Task Output Type](CodeSystem-zw-task-output-type.md)

### ValueSets

* [ZW Laboratory Tests](ValueSet-zw-lab-tests.md)
* [ZW National Laboratory List](ValueSet-zw-laboratories.md)
* [ZW Reason for Test](ValueSet-zw-reason-for-test.md)
* [ZW Specimen Rejection Reasons](ValueSet-zw-rejection-reasons.md)
* [ZW Report Review State](ValueSet-zw-report-review-state.md)
* [ZW Specimen Types](ValueSet-zw-sample-types.md)

### Logicals

* [ZW Lab Order (ZW.LAB.A1)](StructureDefinition-zw-lab-order.md)
* [ZW Lab Result Report (ZW.LAB.A2)](StructureDefinition-zw-lab-result-report.md)

### Resource Profiles

* [ZW Breastfeeding Status](StructureDefinition-zw-breastfeeding-status.md)
* [ZW Health Facility (Location)](StructureDefinition-zw-facility.md)
* [ZW Lab Diagnostic Report](StructureDefinition-zw-lab-diagnostic-report.md)
* [ZW Lab Order Transaction Bundle](StructureDefinition-zw-lab-order-bundle.md)
* [ZW Lab Patient](StructureDefinition-zw-lab-patient.md)
* [ZW Lab Report Document Bundle](StructureDefinition-zw-lab-report-bundle.md)
* [ZW Lab Report Composition](StructureDefinition-zw-lab-report-composition.md)
* [ZW Lab Result Observation](StructureDefinition-zw-lab-result-observation.md)
* [ZW Lab Service Request](StructureDefinition-zw-lab-service-request.md)
* [ZW Lab Order Task](StructureDefinition-zw-lab-task.md)
* [ZW Laboratory (Organization)](StructureDefinition-zw-laboratory.md)
* [ZW Pregnancy Status](StructureDefinition-zw-pregnancy-status.md)
* [ZW Lab Specimen](StructureDefinition-zw-specimen.md)

### Extensions

* [Patient Citizenship](StructureDefinition-citizenship.md)
* [Date of Birth Estimated](StructureDefinition-date-of-birth-estimated.md)
* [Report Review State](StructureDefinition-report-review-state.md)

### Basics

* [lab-order-fulfiller](Basic-lab-order-fulfiller.md)
* [lab-order-placer](Basic-lab-order-placer.md)
* [lab-order-repository](Basic-lab-order-repository.md)
* [lab-result-consumer](Basic-lab-result-consumer.md)
* [lab-result-provider](Basic-lab-result-provider.md)
* [lab-result-repository](Basic-lab-result-repository.md)
* [zw-lab-order-pull](Basic-zw-lab-order-pull.md)
* [zw-lab-order-push](Basic-zw-lab-order-push.md)
* [zw-lab-result-pull](Basic-zw-lab-result-pull.md)
* [zw-lab-result-push](Basic-zw-lab-result-push.md)

### ImplementationGuides

* [Zimbabwe Laboratory Ordering and Results IG](index.md)

### Examples

* [example-zw-lab-order-bundle (Bundle)](Bundle-example-zw-lab-order-bundle.md)
* [example-zw-vl-report-bundle (Bundle)](Bundle-example-zw-vl-report-bundle.md)
* [example-zw-vl-diagnostic-report (DiagnosticReport)](DiagnosticReport-example-zw-vl-diagnostic-report.md)
* [Harare City Health Clinic (Location)](Location-example-order-facility.md)
* [example-zw-vl-observation (Observation)](Observation-example-zw-vl-observation.md)
* [National Virology Laboratory (Organization)](Organization-example-national-virology-lab.md)
* [example-zw-lab-patient (Patient)](Patient-example-zw-lab-patient.md)
* [example-zw-service-request-vl (ServiceRequest)](ServiceRequest-example-zw-service-request-vl.md)
* [example-zw-specimen-plasma (Specimen)](Specimen-example-zw-specimen-plasma.md)
* [example-zw-lab-task-order (Task)](Task-example-zw-lab-task-order.md)
