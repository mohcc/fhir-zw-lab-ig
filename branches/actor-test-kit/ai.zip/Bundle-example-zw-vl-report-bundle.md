# Example — Viral Load Report Document Bundle - Zimbabwe Laboratory Ordering and Results IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example — Viral Load Report Document Bundle**

## Example Bundle: Example — Viral Load Report Document Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-zw-vl-report-bundle",
  "meta" : {
    "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-report-bundle"]
  },
  "identifier" : {
    "system" : "http://mohcc.gov.zw/fhir/lab/identifier/report-document",
    "value" : "ZW-LABDOC-2024-00456"
  },
  "type" : "document",
  "timestamp" : "2024-03-18T16:35:00+02:00",
  "entry" : [{
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Composition/example-zw-vl-composition",
    "resource" : {
      "resourceType" : "Composition",
      "id" : "example-zw-vl-composition",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-report-composition"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Composition_example-zw-vl-composition\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Composition example-zw-vl-composition</b></p><a name=\"example-zw-vl-composition\"> </a><a name=\"hcexample-zw-vl-composition\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-report-composition.html\">ZW Lab Report Composition</a></p></div><p><b>status</b>: Final</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 11502-2}\">Laboratory report</span></p><p><b>date</b>: 2024-03-18 16:30:00+0200</p><p><b>author</b>: <a href=\"Organization-example-national-virology-lab.html\">Organization National Virology Laboratory</a></p><p><b>title</b>: Laboratory Result Report — Viral Load Plasma</p><h3>Attesters</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Mode</b></td><td><b>Time</b></td><td><b>Party</b></td></tr><tr><td style=\"display: none\">*</td><td>Legal</td><td>2024-03-18 16:30:00+0200</td><td><a href=\"Organization-example-national-virology-lab.html\">Organization National Virology Laboratory</a></td></tr></table><p><b>custodian</b>: <a href=\"Organization-example-national-virology-lab.html\">Organization National Virology Laboratory</a></p></div>"
      },
      "status" : "final",
      "type" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "date" : "2024-03-18T16:30:00+02:00",
      "author" : [{
        "reference" : "Organization/example-national-virology-lab"
      }],
      "title" : "Laboratory Result Report — Viral Load Plasma",
      "attester" : [{
        "mode" : "legal",
        "time" : "2024-03-18T16:30:00+02:00",
        "party" : {
          "reference" : "Organization/example-national-virology-lab"
        }
      }],
      "custodian" : {
        "reference" : "Organization/example-national-virology-lab"
      },
      "section" : [{
        "title" : "Laboratory Results",
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "30954-2",
            "display" : "Relevant diagnostic tests/laboratory data note"
          }]
        },
        "entry" : [{
          "reference" : "DiagnosticReport/example-zw-vl-diagnostic-report"
        }]
      }]
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/DiagnosticReport/example-zw-vl-diagnostic-report",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "example-zw-vl-diagnostic-report",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-diagnostic-report"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_example-zw-vl-diagnostic-report\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport example-zw-vl-diagnostic-report</b></p><a name=\"example-zw-vl-diagnostic-report\"> </a><a name=\"hcexample-zw-vl-diagnostic-report\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-diagnostic-report.html\">ZW Lab Diagnostic Report</a></p></div><h2><span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests LTT0013}\">Viral Load Plasma</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 MB}\">Microbiology</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</td></tr><tr><td>When For</td><td>2024-03-18 14:00:00+0200</td></tr><tr><td>Reported</td><td>2024-03-18 16:30:00+0200</td></tr><tr><td>Performer</td><td> <a href=\"Organization-example-national-virology-lab.html\">Organization National Virology Laboratory</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td></tr><tr><td><a href=\"Observation-example-zw-vl-observation.html\"><span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests LTT0013}, {http://loinc.org 20447-9}\">Viral Load Plasma</span></a></td><td>48 copies/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/mL = '/mL')</span></td><td>Final</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/report-review-state",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-report-review-state",
            "code" : "verified",
            "display" : "Verified"
          }]
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/example-zw-service-request-vl"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "MB",
          "display" : "Microbiology"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests",
          "code" : "LTT0013",
          "display" : "Viral Load Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "effectiveDateTime" : "2024-03-18T14:00:00+02:00",
      "issued" : "2024-03-18T16:30:00+02:00",
      "performer" : [{
        "reference" : "Organization/example-national-virology-lab"
      }],
      "resultsInterpreter" : [{
        "reference" : "Organization/example-national-virology-lab"
      }],
      "specimen" : [{
        "reference" : "Specimen/example-zw-specimen-plasma"
      }],
      "result" : [{
        "reference" : "Observation/example-zw-vl-observation"
      }]
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Patient/example-zw-lab-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "example-zw-lab-patient",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_example-zw-lab-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient example-zw-lab-patient</b></p><a name=\"example-zw-lab-patient\"> </a><a name=\"hcexample-zw-lab-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-patient.html\">ZW Lab Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-MaritalStatus M}\">Married</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><code>http://mohcc.gov.zw/fhir/lab/identifier/art-number</code>/HRE/2019/005678</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Indicates that the client's date of birth is an estimate rather than the precise birth date. Corresponds to the Impilo→Senaite contract field `dateOfBirthEstimated`.\"><a href=\"StructureDefinition-date-of-birth-estimated.html\">Date of Birth Estimated</a></td><td colspan=\"3\">false</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/date-of-birth-estimated",
        "valueBoolean" : false
      }],
      "identifier" : [{
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id",
        "value" : "EHR-ZW-00123"
      },
      {
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/art-number",
        "value" : "HRE/2019/005678"
      }],
      "name" : [{
        "family" : "Moyo",
        "given" : ["Rutendo"]
      }],
      "gender" : "female",
      "birthDate" : "1988-04-15",
      "maritalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
          "code" : "M",
          "display" : "Married"
        }]
      }
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Observation/example-zw-vl-observation",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "example-zw-vl-observation",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-result-observation"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_example-zw-vl-observation\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation example-zw-vl-observation</b></p><a name=\"example-zw-vl-observation\"> </a><a name=\"hcexample-zw-vl-observation\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-result-observation.html\">ZW Lab Result Observation</a></p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-example-zw-service-request-vl.html\">ServiceRequest Viral Load Plasma</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>code</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests LTT0013}, {http://loinc.org 20447-9}\">Viral Load Plasma</span></p><p><b>subject</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><p><b>effective</b>: 2024-03-18 14:00:00+0200</p><p><b>value</b>: 48 copies/mL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code/mL = '/mL')</span></p><p><b>method</b>: <span title=\"Codes:\">RT-PCR</span></p><p><b>specimen</b>: <a href=\"Specimen-example-zw-specimen-plasma.html\">Specimen: identifier = http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id#ZW-SPEC-2024-00456; status = available; type = Blood Plasma</a></p></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/example-zw-service-request-vl"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests",
          "code" : "LTT0013",
          "display" : "Viral Load Plasma"
        },
        {
          "system" : "http://loinc.org",
          "code" : "20447-9",
          "display" : "HIV 1 RNA [#/volume] (viral load) in Serum or Plasma by NAA with probe detection"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "effectiveDateTime" : "2024-03-18T14:00:00+02:00",
      "valueQuantity" : {
        "value" : 48,
        "unit" : "copies/mL",
        "system" : "http://unitsofmeasure.org",
        "code" : "/mL"
      },
      "method" : {
        "text" : "RT-PCR"
      },
      "specimen" : {
        "reference" : "Specimen/example-zw-specimen-plasma"
      }
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Specimen/example-zw-specimen-plasma",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "example-zw-specimen-plasma",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-specimen"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_example-zw-specimen-plasma\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen example-zw-specimen-plasma</b></p><a name=\"example-zw-specimen-plasma\"> </a><a name=\"hcexample-zw-specimen-plasma\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-specimen.html\">ZW Lab Specimen</a></p></div><p><b>identifier</b>: <code>http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id</code>/ZW-SPEC-2024-00456</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-sample-types LST006}\">Blood Plasma</span></p><p><b>subject</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-03-15 08:30:00+0200</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id",
        "value" : "ZW-SPEC-2024-00456"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-sample-types",
          "code" : "LST006",
          "display" : "Blood Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "collection" : {
        "collectedDateTime" : "2024-03-15T08:30:00+02:00"
      }
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/ServiceRequest/example-zw-service-request-vl",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "example-zw-service-request-vl",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-service-request"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_example-zw-service-request-vl\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest example-zw-service-request-vl</b></p><a name=\"example-zw-service-request-vl\"> </a><a name=\"hcexample-zw-service-request-vl\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-service-request.html\">ZW Lab Service Request</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>code</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests LTT0013}\">Viral Load Plasma</span></p><p><b>subject</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><p><b>authoredOn</b>: 2024-03-15 08:00:00+0200</p><p><b>locationReference</b>: <a href=\"Location-example-order-facility.html\">Location Harare City Health Clinic</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-reason-for-test routine}\">Routine</span></p><p><b>specimen</b>: <a href=\"Specimen-example-zw-specimen-plasma.html\">Specimen: identifier = http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id#ZW-SPEC-2024-00456; status = available; type = Blood Plasma</a></p></div>"
      },
      "status" : "active",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests",
          "code" : "LTT0013",
          "display" : "Viral Load Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "authoredOn" : "2024-03-15T08:00:00+02:00",
      "locationReference" : [{
        "reference" : "Location/example-order-facility"
      }],
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-reason-for-test",
          "code" : "routine",
          "display" : "Routine"
        }]
      }],
      "specimen" : [{
        "reference" : "Specimen/example-zw-specimen-plasma"
      }]
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Organization/example-national-virology-lab",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "example-national-virology-lab",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-laboratory"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_example-national-virology-lab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization example-national-virology-lab</b></p><a name=\"example-national-virology-lab\"> </a><a name=\"hcexample-national-virology-lab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-laboratory.html\">ZW Laboratory (Organization)</a></p></div><p><b>identifier</b>: <code>http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-laboratories</code>/ZWLPAR001</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/organization-type other}\">Laboratory</span></p><p><b>name</b>: National Virology Laboratory</p></div>"
      },
      "identifier" : [{
        "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-laboratories",
        "value" : "ZWLPAR001"
      }],
      "type" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/organization-type",
          "code" : "other",
          "display" : "Other"
        }],
        "text" : "Laboratory"
      }],
      "name" : "National Virology Laboratory"
    }
  },
  {
    "fullUrl" : "http://mohcc.gov.zw/fhir/lab/Location/example-order-facility",
    "resource" : {
      "resourceType" : "Location",
      "id" : "example-order-facility",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-facility"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_example-order-facility\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location example-order-facility</b></p><a name=\"example-order-facility\"> </a><a name=\"hcexample-order-facility\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-facility.html\">ZW Health Facility (Location)</a></p></div><p><b>status</b>: Active</p><p><b>name</b>: Harare City Health Clinic</p></div>"
      },
      "status" : "active",
      "name" : "Harare City Health Clinic"
    }
  }]
}

```
